<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CV Nguyễn Văn Bình</title>
    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i&display=swap&subset=vietnamese" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700&display=swap&subset=vietnamese" rel="stylesheet">

    <!-- END SLIDER  -->
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/responsive.css">
</head>

<body>
    <div id="wrapper" class="py-3">
        <div id="header">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4  info-left"></div>
                    <div class="col-sm-8 col-sm-12 info-person">
                        <div class="py-3 text-center">
                            <h1 class="h2 font-weight-bold">NGUYỄN VĂN BÌNH</h1>
                            <h4 class="h5 text-uppercase">Lập trình viên PHP</h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="wp-line position-relative" style="width:100%">
                <!-- <div style="width: 135px; height: 154px;" class="thumb-cv">
                    <img src="images/avatar.jpg" alt="">
                </div> -->
                <div class="line"></div>
                <div class="line-left"></div>
                <div class="line-right"></div>
            </div>
        </div>
        <div id="wp-content" class="pb-3 content-one">
            <div class="container">
                <div class="row">
                    <div class="content-left col-md-5 col-sm-12">
                        <div class="info-basic">
                            <p class="h5 font-weight-bold text-uppercase">Thông tin cơ bản</p>
                            <div class="block date-born">
                                <span class="rounded-circle"><i class="fa fa-calendar" aria-hidden="true"></i></span>
                                <span>18/04/1995</span>
                            </div>
                            <div class="block gender">
                                <span class="rounded-circle"><i class="fa fa-user" aria-hidden="true"></i></span>
                                <span>Nam</span>
                            </div>
                            <div class="block number-phone">
                                <span class="rounded-circle"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                <span>0799.500.203</span>
                            </div>
                            <div class="block address-email">
                                <span class="rounded-circle"><i class="fa fa-envelope" aria-hidden="true"></i></span>
                                <span>binh0799500203@gmail.com</span>
                            </div>
                            <div class="block address">
                                <span class="rounded-circle map"><i class="fa fa-map-marker" aria-hidden="true"></i></span>
                                <span>Tịnh Long, Tịnh Thới, Tp Cao Lãnh, Đồng Tháp</span>
                            </div>
                        </div>
                        <!-- END INFO  -->
                        <div class="story-of-program mt-3">
                            <p class="h5 font-weight-bold text-uppercase text-left">Câu chuyện học lập trình</p>
                            <p>Cách đây gần 1 năm, tôi đã lên mạng tự tìm hiểu về lập trình web,
                                thì tình cờ thấy các khóa học online của thầy Phan Văn Cương
                                (Người sáng lập trang <a href="http://unitop.vn/" target="_blank">Unitop</a> về đạo tạo online lập trình web)
                                thì lúc đó tôi bị thuyết phục bởi các lộ trình tự học của thầy đưa ra và
                                các bạn đã học trước đó và chia sẻ lại quá trình học ở Unitop và đã tìm được việc, vậy là tôi đã mua tất cả các khóa học đó, bắt đầu lên mục tiêu và lập kế hoạch trong vòng 5 tháng để học và 4 tháng làm dự án web bán hàng. Sau khi học xong tôi đã có được những
                                kiến thức vô cùng quý giá
                                trong quá trình học cũng như rèn luyện mỗi ngày,
                                tôi đã học được cách tư duy phân tích bài toán, viết ra những checklist công việc
                                để code cho chức năng mà mình làm. Và cuối cùng tôi đã có những sản phẩm mà tự tay mình tạo ra
                                đều này khiến bản thân tôi cảm thấy rất hạnh phúc với những gì mà mình đã chọn.
                            </p>
                        </div>
                        <div class="gold-career">
                            <p class="h5 font-weight-bold text-uppercase">Mục tiêu nghề nghiệp</p>
                            <p class="desc">Không ngừng học hỏi trao dồi những kiến
                                thức về lập trình để phát triển kỹ năng
                                chuyên môn.
                                Được làm nhân viên chính thức của công
                                ty mà mình mong muốn.
                                Sau 1 - 2 năm trở thành lập trình viên chuyên
                                nghiệp về mảng web.
                                Sau 2 - 5 năm trở thành chuyên gia về mảng web.
                            </p>
                        </div>
                        <!-- end gold-career -->
                        <div class="estimate-skill">
                            <p class="h5 font-weight-bold text-uppercase mb-3">Kỹ năng</p>
                            <div class="my-skill">
                                <p class="name-skill">Đọc tài liệu tiếng anh chuyên ngành</p>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 90%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="my-skill">
                                <p class="name-skill">PHP</p>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 80%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="my-skill">
                                <p class="name-skill">Mysql</p>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 80%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="my-skill">
                                <p class="name-skill">Framework BOOTSTRAP</p>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 40%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="my-skill">
                                <p class="name-skill">HTML & CSS</p>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="my-skill">
                                <p class="name-skill">JQUERY AJAX</p>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 80%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                            <div class="my-skill">
                                <p class="name-skill">Tổ chức code mô hinh MVC</p>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 80%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                        <!-- end estimate-skill -->
                        <div class="hobby mt-3">
                            <p class="h5 font-weight-bold text-uppercase ">sở thích</p>
                            <p>- Lập trình</p>
                            <p>- Tìm hiểu công nghệ mới</p>
                            <p>- Nghe podcast Tiếng anh</p>
                            <p>- Cầu lông</p>
                        </div>
                        <div class="skill-professional pt-3">
                            <p class="h5 font-weight-bold text-uppercase border-bottom pb-2 mb-3">kỹ năng chuyên môn</p>
                            <div class="skill-pro">
                                <p class="font-weight-bold text-uppercase">PHP</p>
                                Kiến thức PHP</br>
                                <p>+ Checklist những việc cần làm để xử lí một chức năng nào đó.</br>
                                    + Nắm được dữ liệu trong php, những phép toán trong php, cấu trúc
                                    điều khiển và vòng lặp. </br>
                                    + Hiểu rõ tầm quan trọng khi viết hàm và cách
                                    đặt tên hàm rõ ràng dễ hiểu. </br>
                                    + Nắm được các kiểu dữ liệu truyền lên server: POST và GET. </br>
                                    + Biết chuẩn hóa dữ liệu form. </br>
                                    + Hiểu phiên làm việc: COOKIE, SESSION. </br>
                                    + Nắm được các thư viện hàm.
                                    hiểu được cách hoạt động của mô hình MVC (model controller,view)</br>
                                    + Biết làm việc giữa PHP với Ajax </br>
                                    + Biết tạo đường link thân thiện(friendlyUrl) cho website.
                                </p>
                                <p>Biết làm việc với Hệ quản trị cơ sở dữ liệu Mysql và các thao tác trên phpmyadmin</p>
                            </div>
                            <div class="skill-pro">
                                <p class="font-weight-bold text-uppercase">Laravel</p>
                                Kiến thức Laravel</br>
                                <p>+ Checklist những việc cần làm để xử lí một chức năng nào đó.</br>
                                    + Nắm được các kiểu route </br>
                                    + Biết các thao tác cơ sở dữ liệu qua Query Builder và ORM. </br>
                                    + Biết các làm việc với controller, model, master layout. </br>
                                    + Biết cách kiểm soát truy cập middleware, gửi mail, sử dụng helper string, url. </br>
                                    + Hiểu phiên làm việc: COOKIE, SESSION. </br>
                                    + Nắm được các kiểu dữ liệu truyền lên server: POST và GET. </br>
                                    + Biết chuẩn hóa dữ liệu form. </br>
                                    + Hiểu được cách hoạt động của mô hình MVC (model controller,view)
                                </p>
                            </div>
                            <div class="skill-pro">
                                <p class="font-weight-bold text-uppercase">HTML và CSS</p>
                                <p>- Kiến thức về HTML:
                                    + Biết tư duy phân tích thiết kế khung layout.</br>
                                    + Nắm được các bộ thẻ cốt lõi để xây dựng khung HTML.</br>
                                    - Kiến thức về CSS: </br>
                                    + Các bộ chọn trong css như: selector id, selector css, selector con cháu, selector befor, after..</br>
                                    + Các thuộc tính cho text, thuộc tính định dạng cho khối.</br>
                                    + Các hiệu ứng như: làm trong suốt khối với opacity, làm mềm quá trình thay đổi css với transition, Xoay khối với Rotate..</br>
                                    + Biết bố cục trang với Flexbox.</br>
                                    + Quy tắc đặt tên chuyên nghiệp cho class, id.</br>
                                    + Các plugin quan trọng như: thêm google font, fontawesome, slider với olw carousel, nhúng các tiện ích của facebook.</br>
                                    - Biết cách sử dụng Photoshop cơ bản để chuyển PSD thành HTML CSS.
                                </p>
                            </div>
                            <div class="skill-pro">
                                <p class="font-weight-bold text-uppercase">BOOTSTRAP</p>
                                <p>
                                    -Kiến thức Bootstrap.</br>
                                    +Xây dựng la yout website responsive với Grid System.</br>
                                    +Nắm được các
                                    class cơ bản để xây dụng giao diện nhanh hơn. Sử dụng được các
                                    cấu trúc để xây dụng khung trong HTML như: Navbar menu
                                    responsive, Carousel slideshow, Các loại Form, các loại Card trong
                                    bootstrap..
                                </p>
                            </div>
                            <div class="skill-pro">
                                <p class="font-weight-bold text-uppercase">JQUERY</p>
                                - Kiến thức JQUERY
                                <p>+ Các nhóm selector.</br>
                                    + Các phương thức xử lí trong jquery: thuộc tính, class, giá trị tìm kiếm lọc, </br>
                                    + Hiệu ứng: show, hide, slide </br>
                                    + Sự kiện trong jquery </br>
                                </p>
                            </div>

                        </div>
                    </div>
                    <div class="content-right col-md-7 col-sm-12 py-3">
                        <div class="study">
                            <p class="h5 font-weight-bold text-uppercase border-bottom pb-2 mb-3">học vấn</p>
                            <p class="pt-3">Đang học Đại Học Cần Thơ</p>
                            <p class="departure">Ngành học: Khoa học máy tính</p>
                            <!-- <p>Xếp loại: giỏi</p> -->
                        </div>

                        <div class="project-finish pt-3">
                            <p class="h5 font-weight-bold text-uppercase border-bottom pb-2 mb-3">Dự án đã làm</p>
                            <div class="info-project">
                                <strong class="text-uppercase">Hệ thống bán điện thoại trực tuyến</strong>
                                <p class="pt-3">Đây là dự án để khách hàng có thể tự đặt hàng online, tiết kiệm thời
                                    gian.</p>
                                <p>- Link web: </p>
                                <span>+ Client: <a class="link-access one" href="http://vanbinh.unitopcv.com/" target="_blank">http://vanbinh.unitopcv.com/</a></span>
                                <p>+ Admin: <a class="link-access two" href="http://vanbinh.unitopcv.com/admin/" target="_blank">http://vanbinh.unitopcv.com/admin/</a></p>
                                <p>Ngôn ngữ: PHP</p>
                                <p>Thư viện: JQUERY và AJAX.</p>
                                <p>Cơ sở dữ liệu: Mysql</p>
                                <p>Framework front-end: Bootstrap</p>
                                <!-- <p>Code theo mô hình MVC</p> -->
                                <p>Dự án bao gồm 2 phần: Client (phía khách hàng) và Admin (Phía
                                    quản trị viên).
                                </p>

                                <!-- <p>Có sử dụng Phpmailler</p> -->
                                <!-- <p>CÓ chức năng phân quyền chuyen sâu</p> -->
                                <!-- <p>có chức năng thống kê doanh thu: sử dụng highcharts</p> -->
                                <strong>- Các module của Client:</strong>
                                <ul class="list-module">
                                    <li><i>Sản phẩm: </i>
                                        <ul>
                                            <li>Danh sách sản phẩm theo thương hiệu</li>
                                            <li>Danh sách sản phẩm giảm giá</li>
                                            <li>Chi tiết sản phẩm</li>
                                            <li>Review và rating sản phẩm</li>
                                            <li>Bộ lọc sản phẩm theo giá, rating, storage, ram, color</li>
                                            <li>Tìm kiếm sản phẩm bằng Full-Text Search</li>
                                            <li>Hệ thống phân trang nâng cao</li>
                                            <li>Nhận tên, email người dùng khi sản phẩm out of stock để thông báo người dùng khi sản phẩm có hàng</li>
                                        </ul>
                                    </li>
                                    <li><i>Hệ thống recommend: </i>
                                        <ul>
                                            <li>Customers who bought this item also bought</li>
                                            <li>Related Products</li>
                                            <li>Most Order Products</li>
                                            <li>Most Rating Products</li>
                                        </ul>
                                    </li>
                                    <li><i>User: </i>
                                        <ul>
                                            <li>Đăng ký</li>
                                            <li>Đăng nhập</li>
                                            <li>Thay đổi mật khẩu</li>
                                            <li>Quên mật khẩu</li>
                                            <li>Lịch sử order</li>
                                            <li>Chức năng thông báo khi người khác trả lởi và thích comment</li>
                                        </ul>
                                    </li>
                                    <li><i>Bài viết:</i>
                                        <ul>
                                            <li>Danh sách bài viết về 1 sản phẩm</li>
                                            <li>Danh sách bài viết nổi bật</li>
                                            <li>Danh sách bài viết mới</li>
                                            <li>Danh sách bài viết nhiều comment</li>
                                            <li>Danh sách bài viết cho sản phẩm mới</li>
                                            <li>Danh sách bài viết nhiều lượt xem</li>
                                            <li>Chi tiết bài viết</li>
                                            <li>Hệ thống comment tự xây dựng</li>
                                            <li>Chức năng view more</li>
                                        </ul>
                                    </li>
                                    <li><i>Chat:</i>
                                        <ul>
                                            <li>Chức năng tự xây dựng bằng kỹ thuật ajax</li>
                                            <li>Thêm message và icon emotion</li>
                                            <li>Xóa message</li>
                                            <li>Thêm icon emotion</li>
                                        </ul>
                                    </li>

                                    <li><i>Giỏ hàng:</i>
                                        <ul>
                                            <li>Phân giỏ hàng cho người dùng login và không login</li>
                                            <li>Thêm, xóa, cập nhập giỏ hàng</li>
                                            <li>Chức năng wishlist</li>
                                        </ul>
                                    </li>
                                    <li><i>Mã giảm giá</i>
                                        <ul>
                                            <li>Sử dụng mã giảm giá</li>
                                            <li>Xóa mã giảm giá</li>
                                            <li>Danh sách mã giảm giá</li>
                                        </ul>
                                    </li>
                                    <li><i>Thanh toán:</i>
                                        <ul>
                                            <li>Phân ra cho người dùng login và không login</li>
                                            <li>Chức năng chọn 1 trong nhiều địa chỉ shipping đối với người dùng login</li>
                                            <li>Thanh toán qua cổng thanh toán Stripe</li>
                                            <li>Biên lai đơn hàng</li>
                                        </ul>
                                    </li>
                                </ul>
                                <strong>- Các module của Admin:</strong>
                                <ul class="list-module">
                                    <li><i>User:</i>
                                        <ul>
                                            <li>Thêm người dùng quản trị</li>
                                            <li>Xóa tạm thời và vĩnh viễn người dùng quản trị</li>
                                            <li>Khôi phục người dùng quản trị</li>
                                            <li>Cập nhật người dùng quản trị</li>
                                            <li>Danh sách người dùng quản trị theo các trạng thái</li>
                                        </ul>
                                    </li>
                                    <li><i>Thương hiệu</i>:
                                        <ul>
                                            <li>Thêm thương hiệu</li>
                                            <li>Cập nhật thương hiệu</li>
                                            <li>Xóa thương hiệu</li>
                                            <li>Danh sách thương hiệu</li>
                                        </ul>
                                    </li>
                                    <li><i>Sản phẩm:</i>
                                        <ul>
                                            <li>Danh sách sản phẩm theo thương hiệu</li>
                                            <li>Cập nhật sản phẩm</li>
                                            <li>Thêm thương hiệu vào 1 sản phẩm</li>
                                            <li>Xóa thương hiệu trong 1 sản phẩm</li>
                                            <li>Di chuyển sản phẩm đến thương hiệu khác</li>
                                            <li>Thêm thuộc tính vào 1 sản phẩm</li>
                                            <li>Xóa thuộc tính trong 1 sản phẩm</li>
                                            <li>Gửi thông báo có hàng cho khác hàng đăng ký nhận thông báo khi sản phẩm out of stock</li>
                                        </ul>
                                    </li>
                                    <li><i>Giảm giá:</i>
                                        <ul>
                                            <li>Giảm giá sản phẩm</li>
                                            <li>Danh sách các sản phẩm giảm giá</li>
                                        </ul>
                                    </li>
                                    <li><i>Thuộc tính sản phẩm:</i>
                                        <ul>
                                            <li>Thêm thuộc tính</li>
                                            <li>Danh sách thuộc tính</li>
                                            <li>Cập nhật thuộc tính</li>
                                        </ul>
                                    </li>
                                    <li><i>Inventory:</i>
                                        <ul>
                                            <li>Liệt kê sản phẩm out of stock</li>
                                            <li>Thêm số lượng sản phẩm</li>
                                        </ul>
                                    </li>
                                    <li><i>Bài viết:</i>
                                        <ul>
                                            <li>Thêm bài viết</li>
                                            <li>Xóa bài viết</li>
                                            <li>Danh sách các bài viết theo 1 sản phẩm</li>
                                            <li>Xóa các bài viết theo 1 sản phẩm</li>
                                        </ul>
                                    </li>
                                    <li><i>Comment bài viết:</i>
                                        <ul>
                                            <li>Danh sách các comment theo các trạng thái</li>
                                            <li>Duyệt comment</li>
                                            <li>Xóa comment</li>
                                            <li>Khôi phục comment</li>
                                        </ul>
                                    </li>
                                    <li><i>Review sản phẩm:</i>
                                        <ul>
                                            <li>Danh sách các review theo các trạng thái</li>
                                            <li>Duyệt review</li>
                                            <li>Xóa review</li>
                                            <li>Khôi phục review</li>
                                        </ul>
                                    </li>
                                    <li><i>Order:</i>
                                        <ul>
                                            <li>Danh sách order theo các tiêu chí</li>
                                            <li>Chi tiết order</li>
                                            <li>Xác nhận order</li>
                                        </ul>
                                    </li>
                                    <li><i>Shopping cart:</i>
                                        <ul>
                                            <li>Liệt kê số lượng phẩm cũ trong giỏ hàng</li>
                                            <li>Xóa sản phẩm cũ trong giỏ hàng</li>
                                        </ul>
                                    </li>
                                    <li><i>Chat:</i>
                                        <ul>
                                            <li>Chat với người dùng bằng kỹ thuật ajax</li>
                                            <li>Thêm message và icon emotion</li>
                                            <li>Xóa message</li>
                                            <li></li>
                                        </ul>
                                    </li>
                                    <li><i>Slider:</i>
                                        <ul>
                                            <li>Thêm slider</li>
                                            <li>Danh sách slider theo các trạng thái</li>
                                            <li>Xóa slider</li>
                                            <li>Cập nhật slider</li>
                                        </ul>
                                    </li>
                                    <li><i>Mã giảm giá:</i>
                                        <ul>
                                            <li>Thêm mã giảm giá tự động</li>
                                            <li>Danh sách mã giảm giá</li>
                                            <li>Xóa mã giảm giá</li>
                                            <li>Disable mã giảm giá</li>
                                            <li>Enable mã giảm giá</li>
                                        </ul>
                                    </li>
                                    <li><i>Sản phẩm liên quan:</i>
                                        <ul>
                                            <li>Thêm sản phẩm liên quan</li>
                                            <li>Danh sách các sản phẩm liên quan</li>
                                        </ul>
                                    </li>
                                </ul>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="owlcarousel/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script src="js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
</body>